package com.e_commerce.e_commerce.model;

public enum ApiStatus {
    SUCCESS, ERROR, SERVERERROR, UNSATISFIED, NOT_FOUND
}
